package ultimate.permission.manager;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    private static final String TAG = "PermHook";
    private static final String TARGET_CLASS = "com.android.server.pm.PackageManagerService";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals("android")) {
            return;
        }
        XposedBridge.log(TAG + ": Loading hook for " + lpparam.packageName);
        try {
            Class<?> packageParserPackageClass = XposedHelpers.findClass("android.content.pm.PackageParser.Package", lpparam.classLoader);
            Class<?> basePermissionClass = XposedHelpers.findClass("com.android.server.pm.BasePermission", lpparam.classLoader);
            Class<?> targetClass = XposedHelpers.findClass(TARGET_CLASS, lpparam.classLoader);
            XposedBridge.log(TAG + ": Found required classes");

            // Hook the enforceDeclaredAsUsedAndRuntimeOrDevelopmentPermission method
            XposedHelpers.findAndHookMethod(
                    TARGET_CLASS,
                    lpparam.classLoader,
                    "enforceDeclaredAsUsedAndRuntimeOrDevelopmentPermission",
                    packageParserPackageClass,
                    basePermissionClass,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            XposedBridge.log(TAG + ": Method enforceDeclaredAsUsedAndRuntimeOrDevelopmentPermission hooked successfully");
                            param.setResult(null);
                            XposedBridge.log(TAG + ": Security check bypassed");
                        }
                    }
            );

            // Hook the grantRuntimePermission method
            XposedHelpers.findAndHookMethod(
                    TARGET_CLASS,
                    lpparam.classLoader,
                    "grantRuntimePermission",
                    String.class,
                    String.class,
                    int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            XposedBridge.log(TAG + ": Method grantRuntimePermission hooked successfully");
                            String packageName = (String) param.args[0];
                            String name = (String) param.args[1];
                            int userId = (int) param.args[2];

                            // Retrieve the PackageSetting instance
                            Object mPackages = XposedHelpers.getObjectField(param.thisObject, "mPackages");
                            Object pkg = XposedHelpers.callMethod(mPackages, "get", packageName);
                            Object mSettings = XposedHelpers.getObjectField(param.thisObject, "mSettings");
                            Object mPermissions = XposedHelpers.getObjectField(mSettings, "mPermissions");
                            Object bp = XposedHelpers.callMethod(mPermissions, "get", name);

                            // Get the PackageSetting ps
                            Object packageSetting = XposedHelpers.getObjectField(pkg, "mExtras");

                            // Get PermissionsState from PackageSetting (ps)
                            Object permissionsState = XposedHelpers.callMethod(packageSetting, "getPermissionsState");

                            // Grant permission and handle the result
                            if ((int) XposedHelpers.callMethod(permissionsState, "grantInstallPermission", bp) !=
                                    XposedHelpers.getStaticIntField(permissionsState.getClass(), "PERMISSION_OPERATION_FAILURE")) {
                                XposedHelpers.callMethod(param.thisObject, "scheduleWriteSettingsLocked");
                                return;
                            }

                        }
                    }
            );

            // Hook the revokeRuntimePermission method
            XposedHelpers.findAndHookMethod(
                    TARGET_CLASS,
                    lpparam.classLoader,
                    "revokeRuntimePermission",
                    String.class,
                    String.class,
                    int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            XposedBridge.log(TAG + ": Method revokeRuntimePermission hooked successfully");
                            String packageName = (String) param.args[0];
                            String name = (String) param.args[1];
                            int userId = (int) param.args[2];

                            // Retrieve the PackageSetting instance
                            Object mPackages = XposedHelpers.getObjectField(param.thisObject, "mPackages");
                            Object pkg = XposedHelpers.callMethod(mPackages, "get", packageName);
                            Object mSettings = XposedHelpers.getObjectField(param.thisObject, "mSettings");
                            Object mPermissions = XposedHelpers.getObjectField(mSettings, "mPermissions");
                            Object bp = XposedHelpers.callMethod(mPermissions, "get", name);

                            // Get the PackageSetting ps
                            Object packageSetting = XposedHelpers.getObjectField(pkg, "mExtras");

                            // Get PermissionsState from PackageSetting (ps)
                            Object permissionsState = XposedHelpers.callMethod(packageSetting, "getPermissionsState");

                            // Revoke permission and handle the result
                            if ((int) XposedHelpers.callMethod(permissionsState, "revokeInstallPermission", bp) !=
                                    XposedHelpers.getStaticIntField(permissionsState.getClass(), "PERMISSION_OPERATION_FAILURE")) {
                                XposedHelpers.callMethod(param.thisObject, "scheduleWriteSettingsLocked");
                                return;
                            }

                        }
                    }
            );

        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook: " + t.getMessage());
            XposedBridge.log(t);
        }
    }
}
